<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\RecipeController;

// Route::get('/', [RecipeController::class, 'landingPage'])->name('landing-page');
// Route::get('/insert', [PageController::class, 'insertPage'])->name('insert-page');
// Route::post('/insert', [PageController::class, 'insert']);
// Route::get('/detail/{id}', [PageController::class, 'landingwithId']);
// Route::post('/delete-recipe', [PageController::class, 'deleteRecipe']);
// Route::post('/recipe-update', [PageController::class, 'update']);


Route::get('/', [RecipeController::class, 'index'])->name('index');
Route::resource('recipes', RecipeController::class);
Route::get('/login', [RecipeController::class, 'loginPage'])->name('login');
Route::post('/login', [RecipeController::class, 'loginForm']);
Route::post('/logout', [RecipeController::class, 'logout']);
Route::get('/register', [RecipeController::class, 'registerPage'])->name('register');
Route::post('/register', [RecipeController::class, 'registerForm']);
