

<?php $__env->startSection('title', 'Landing Page'); ?>

<?php $__env->startSection('content'); ?>  
    <div class="container">
        <?php $__sessionArgs = ['success'];
if (session()->has($__sessionArgs[0])) :
if (isset($value)) { $__sessionPrevious[] = $value; }
$value = session()->get($__sessionArgs[0]); ?>
            <div class="alert alert-success" role="alert"> <?php echo e($value); ?> </div>
        <?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?>
        <div class="d-grid gap-2 d-md-flex">
            <a class="btn btn-success btn-sm" href="<?php echo e(route('recipes.create')); ?>"> <i class="fa fa-plus"></i> Create New Recipe</a>
        </div>
        <br><br>
        <div style="display: flex; justify-content: space-between; margin:0 -10px">
            <?php $__empty_1 = true; $__currentLoopData = $recipes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="card" style="width: 30px; box-shadow:0 0 .75rem; flex:1; margin:0 10px">
                    <img src="/image/<?php echo e($resep->image); ?>" class="card-img-top" width="100px">
                    <div class="card-body">
                    <h5 class="card-title"><?php echo e($resep->nama); ?></h5>
                    <p class="card-text"><?php echo e($resep->deskripsi); ?></p>
                    <a href="<?php echo e(route('recipes.edit',$resep->id)); ?>" class="btn btn-primary">Check</a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div>
                    <p>There are no data.</p>
                </div>
            <?php endif; ?>
        </div>
        <br><br>
        <?php echo $recipes->withQueryString()->links('pagination::bootstrap-5'); ?>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('recipes.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\CulinaireCollection\resources\views/recipes/index.blade.php ENDPATH**/ ?>