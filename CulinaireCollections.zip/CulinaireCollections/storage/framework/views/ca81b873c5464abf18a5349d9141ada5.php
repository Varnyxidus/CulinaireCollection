

<?php $__env->startSection('title', 'Landing Page'); ?>

<?php $__env->startSection('content'); ?>
    
    <div style="display: flex; justify-content: space-between; margin:0 -10px">
        <?php if($recipes): ?>
            <?php $__currentLoopData = $recipes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card" style="width: 30px; box-shadow:0 0 .75rem; flex:1; margin:0 10px">
                <img src="/image/nasgor.jpg" class="card-img-top">
                <div class="card-body">
                <h5 class="card-title"><?php echo e($resep->nama); ?></h5>
                <p class="card-text"><?php echo e($resep->deskripsi); ?></p>
                <a href="#" class="btn btn-primary">Check</a>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>

    
    <div>
        <form method="POST" action="/recipe-update">
            <?php echo csrf_field(); ?>
            <div>
                <label for="id">id</label>
                <input type="text" name="id" id="id"/>
            </div>
            <div>
                <label for="nama">nama</label>
                <input type="text" name="nama" id="nama"/>
            </div>
            <div>
                <label for="deskripsi">deskripsi</label>
                <input type="text" name="deskripsi" id="deskripsi"/>
            </div>
            <div>
                <label for="porsi">porsi</label>
                <input type="number" name="porsi" id=""/>
            </div>
            <div>
                <label for="bahan">bahan</label>
                <input type="text" name="bahan" id="bahan"/>
            </div>
            <div>
                <label for="alat">alat</label>
                <input type="text" name="alat" id="alat"/>
            </div>
            <div>
                <label for="tutorial">tutorial</label>
                <input type="text" name="tutorial" id="tutorial"/>
            </div>
            <div>
                <button type="submit" >Submit</button>
            </div>

        </form>
    </div>
<?php $__env->stopSection(); ?>

    

    
<?php echo $__env->make('Pages.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\CulinaireCollection\resources\views/landing.blade.php ENDPATH**/ ?>