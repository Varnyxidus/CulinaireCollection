<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login Page</title>
    <link rel="stylesheet" href="/bootstrap-5.3.3-dist/css/bootstrap.css">   

    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh; /* Adjust height as needed */
        }

        .card {
            width: 400px; /* Adjust width as needed */
            height: auto; /* Allow height to adjust based on content */
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
        }

        .card-header {
            display: flex;
            justify-content: center;
            align-items: center;
            width: 100%; /* Make header span the full width of the card */
            background-color: #212529;
            color: rgb(255, 165, 0);
            font-family: 'Courier New', Courier, monospace;
            font-size: 24px; /* Increase font size */
        }

        .card-body {
            flex-grow: 1; /* Make card body expand to fill remaining space */
            text-align: center;
            background-color: white;
        }
    </style>
</head>
<body>
    <div class="card">
        <h2 class="card-header">Login</h2>
        <div class="card-body">
            <form method="POST" action="/login">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label for="email" class="form-label"><strong>Email: </strong></label>
                    <input type="email" name="email" id="email">
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label"><strong>Password: </strong></label>
                    <input type="password" name="password" id="password">
                </div>
                <?php if($errors->has('credentials')): ?>
                    <div>
                        <p style="color: red"><?php echo e($errors->first('credentials')); ?></p>
                    </div>
                <?php endif; ?>

                <button type="submit" class="btn btn-success"><i class="fa-solid fa-floppy-disk"></i>Submit</button>
            </form>
        </div>
        <p>don't have an account yet? <a href="/register" style="color:aqua">Register now</a></p>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\CulinaireCollections\resources\views/login.blade.php ENDPATH**/ ?>