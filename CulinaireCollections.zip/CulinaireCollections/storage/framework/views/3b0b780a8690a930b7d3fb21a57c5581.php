<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Home</title>
    <style>
    {
          box-sizing: border-box;
          /* Width Akhir = Width Sisa + Padding + Border /
          / Width Akhir = Width Yang Kalian tentuin + padding + border */
            margin: 0;
            padding: 0;
    }
    </style>
</head>

<body>
    <header>
        <div style="background-color: orange; width: 97vw; height: 50px; color: white; display:flex; justify-content: space-between; align-items: center; padding: 10px;">
            <div>
                <h1>CulinaireCollection</h1>
            </div>
            <div>
                <a href="/register" style="color: white; text-decoration: none">Register</a>
                <a href="/login" style="color: white; text-decoration: none">Login</a>
            </div>
        </div>
    </header>

</body>

</html><?php /**PATH C:\xampp\htdocs\CulinaireCollection\resources\views/home.blade.php ENDPATH**/ ?>