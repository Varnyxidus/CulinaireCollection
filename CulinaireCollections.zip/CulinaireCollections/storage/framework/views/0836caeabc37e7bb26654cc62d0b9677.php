<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet" href="/bootstrap-5.3.3-dist/css/bootstrap.css">
</head>



<body>
    <header>
        <nav class="navbar fixed-top bg-body-tertiary" data-bs-theme="dark">
            <div class="container-fluid">
              <a class="navbar-brand" style="color: rgb(255, 165, 0); font-family:'Courier New', Courier, monospace; font-weight: bold">CulinaireCollection</a>
            <form method="GET" action="/" class="d-flex" role="search">
                <?php echo csrf_field(); ?>
                <div>
                    <input class="form-control me-2" type="search" name="search" id="search" placeholder="search recipe..." aria-label="Search"/>
                </div> 
                <div>
                    <button type="submit" class="btn btn-outline-warning">Search</button>
                </div>
            </form>
              <button type="button" class="btn btn-outline-warning">Login</button>
            </div>
          </nav>
    </header>
    <div style="padding-top: 100px">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</body>

</html><?php /**PATH E:\CulinaireCollection\resources\views/recipes/layout.blade.php ENDPATH**/ ?>