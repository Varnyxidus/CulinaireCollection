

<?php $__env->startSection('title', 'Insert Page'); ?>

<?php $__env->startSection('content'); ?>

    <h1>Insert Menu</h1>
    <form method="POST" action="insert">
        <?php echo csrf_field(); ?>
        <div>
            <label for="nama">nama</label>
            <input type="text" name="nama" id="nama"/>
        </div>
        <div>
            <label for="deskripsi">deskripsi</label>
            <input type="text" name="deskripsi" id="deskripsi"/>
        </div>
        <div>
            <label for="porsi">porsi</label>
            <input type="number" name="porsi" id=""/>
        </div>
        <div>
            <label for="bahan">bahan</label>
            <input type="text" name="bahan" id="bahan"/>
        </div>
        <div>
            <label for="alat">alat</label>
            <input type="text" name="alat" id="alat"/>
        </div>
        <div>
            <label for="tutorial">tutorial</label>
            <input type="text" name="tutorial" id="tutorial"/>
        </div>
        
        <div>
            <button type="submit" >Submit</button>
        </div>

    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('pages.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CulinaireCollection\CulinaireCollection\resources\views/insert.blade.php ENDPATH**/ ?>