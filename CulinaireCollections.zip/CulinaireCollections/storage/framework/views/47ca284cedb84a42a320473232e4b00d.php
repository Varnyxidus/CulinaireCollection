

<?php $__env->startSection('title', 'Detail Recipes'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card">
        <!-- Header -->
        <div class="card-header" style="background-color: #f8f9fa;">
            <a href="<?php echo e(route('recipes.index')); ?>" style="background-color:gainsboro" class="btn btn-light btn-sm"><i class="fa fa-arrow-left"></i> Back
            </a>
            <h3 class="text-center"><?php echo e($recipe->nama); ?></h3>
        </div>

        <!-- Gambar resep -->
        <div class="text-center mt-3">
            
            <img src="/image/<?php echo e($recipe->image); ?>" class="card-img-top" alt="<?php echo e($recipe->nama); ?>" style="width: 300px;">
        </div>

        <!-- Form -->
        <form action="<?php echo e(route('recipes.update', $recipe->id)); ?>" method="POST" id="recipeForm">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <!-- Tab Navigation -->
            <ul class="nav nav-tabs mt-3" id="recipeTab" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="about-tab" data-bs-toggle="tab" data-bs-target="#about"
                        type="button" role="tab">About</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="bahan-tab" data-bs-toggle="tab" data-bs-target="#bahan" type="button"
                        role="tab">Bahan & Alat</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="tutorial-tab" data-bs-toggle="tab" data-bs-target="#tutorial"
                        type="button" role="tab">Tutorial</button>
                </li>
            </ul>

            <!-- content -->
            <div class="tab-content p-3">
                <!-- About Tab nya -->
                <div class="tab-pane fade show active" id="about" role="tabpanel">
                    <h5>Deskripsi:</h5>
                    <textarea class="form-control" name="deskripsi" rows="3"
                        disabled><?php echo e($recipe->deskripsi); ?></textarea>
                </div>

                <!-- Bahan dan alat tab -->
                <div class="tab-pane fade" id="bahan" role="tabpanel">
                    <h5>Bahan:</h5>
                    <textarea class="form-control" name="bahan" rows="3" disabled><?php echo e($recipe->bahan); ?></textarea>

                    <h5>Alat:</h5>
                    <textarea class="form-control" name="alat" rows="3" disabled><?php echo e($recipe->alat); ?></textarea>
                </div>

                <!-- Tutorial tab -->
                <div class="tab-pane fade" id="tutorial" role="tabpanel">
                    <h5>Tutorial:</h5>
                    <textarea class="form-control" name="tutorial" rows="3" disabled><?php echo e($recipe->tutorial); ?></textarea>
                </div>
            </div>

            <?php if(auth()->guard()->check()): ?>
            <!-- Button -->
            <div class="d-flex justify-content-end p-3">
                <!-- Edit button -->
                <button type="button" class="btn btn-warning me-2" id="editBtn">Edit</button>

                <!-- Update Form -->
                <form action="<?php echo e(route('recipes.update', $recipe->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <button type="submit" class="btn btn-success d-none me-2" id="updateBtn">Update</button>
                </form>

                <!-- Delete Form -->
                <form action="<?php echo e(route('recipes.destroy', $recipe->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger">Delete</button>
                </form>
            </div>
            <?php else: ?>
            <?php endif; ?>
        </form>
    </div>
</div>

<script>
    document.getElementById('editBtn').addEventListener('click', function () {
        document.querySelectorAll('textarea').forEach(function (textarea) {
            textarea.disabled = false;
        });
        document.getElementById('updateBtn').classList.remove('d-none');
        document.getElementById('editBtn').disabled = true;
    });

    document.getElementById('updateBtn').addEventListener('click', function (event) {
        event.preventDefault();
        this.closest('form').submit();
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('recipes.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CulinaireCollections\resources\views/recipes/edit.blade.php ENDPATH**/ ?>