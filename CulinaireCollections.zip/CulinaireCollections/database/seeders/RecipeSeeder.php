<?php

namespace Database\Seeders;

use App\Models\Recipe;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class RecipeSeeder extends Seeder
{

    public function run(): void
    {
        Recipe::create([
            'nama' => 'Nasi Goreng',
            'deskripsi' => 'nasi goreng enak puol',
            'porsi' => 2,
            'bahan' => 'nasi, telur, garam, merica, bawang putih',
            'alat' => 'panci, mangkok, sudok',
            'tutorial' => '1) Siapkan alat dan bahan. 2) Masak. 3) Sajikan dan makan.',
            'image' => 'nasgor.jpg'
        ]);

        Recipe::create([
            'nama' => 'Bubur Ayam',
            'deskripsi' => 'bubur ayam enak banget gila',
            'porsi' => 1,
            'bahan' => 'bubur, ayam, topping',
            'alat' => 'mangkok',
            'tutorial' => '1) Masukkan bubur di mangkok. 2) Taburin toppingnya. 3) Makan rek.',
            'image' => 'buburayam.jpg'
        ]);

        Recipe::create([
            'nama' => 'Pizza',
            'deskripsi' => 'Pizza lezatos',
            'porsi' => 3,
            'bahan' => 'Pizza Meat Lovers dari Pizza Hut',
            'alat' => 'Pisau',
            'tutorial' => '1) Potong pizzanya jadi 8 bagian. 2) Ambil 1 potongan. 3) Makan bg.',
            'image' => 'pizza.jpg'
        ]);
    }
}
