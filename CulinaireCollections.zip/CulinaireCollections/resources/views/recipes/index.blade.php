@extends('recipes.layout')

@section('title', 'Landing Page')

@section('content')
    @auth
    <div class="container">
        @session('success')
            <div class="alert alert-success" role="alert"> {{ $value }} </div>
        @endsession
        <h2>Hello {{$username}}!</h2>
        <br>
        <div class="d-grid gap-2 d-md-flex">
            <a class="btn btn-success btn-sm" href="{{ route('recipes.create') }}"> <i class="fa fa-plus"></i> Create New Recipe</a>
        </div>
        <br>
        <div style="display: flex; justify-content: space-between; margin:0 -10px">
            @forelse ($recipes as $resep)
                <div class="card" style="width: 30px; box-shadow:0 0 .75rem; flex:1; margin:0 10px">
                    <img src="/image/{{ $resep->image }}" class="card-img-top" width="100px">
                    <div class="card-body">
                    <h5 class="card-title">{{$resep->nama}}</h5>
                    <p class="card-text">{{$resep->deskripsi}}</p>
                    <a href="{{ route('recipes.edit',$resep->id) }}" class="btn btn-primary">Check</a>
                    </div>
                </div>
            @empty
                <div>
                    <p>There are no data.</p>
                </div>
            @endforelse
        </div>
        <br><br>
        {!! $recipes->withQueryString()->links('pagination::bootstrap-5') !!}
    </div>
    @else
    <div class="container">
        <div style="display: flex; justify-content: space-between; margin:0 -10px">
            @forelse ($recipes as $resep)
                <div class="card" style="width: 30px; box-shadow:0 0 .75rem; flex:1; margin:0 10px">
                    <img src="/image/{{ $resep->image }}" class="card-img-top" width="100px">
                    <div class="card-body">
                    <h5 class="card-title">{{$resep->nama}}</h5>
                    <p class="card-text">{{$resep->deskripsi}}</p>
                    <a href="{{ route('recipes.edit',$resep->id) }}" class="btn btn-primary">Check</a>
                    </div>
                </div>
            @empty
                <div>
                    <p>There are no data.</p>
                </div>
            @endforelse
        </div>
        <br><br>
        {!! $recipes->withQueryString()->links('pagination::bootstrap-5') !!}
    </div>
    @endauth

@endsection