@extends('recipes.layout')

@section('title', 'Insert Recipes')

@section('content')  
<div class="container">
    <div class="card">
        <h2 class="card-header" style="background-color: #212529; color: rgb(255, 165, 0); font-family : 'Courier New', Courier, monospace">Add New Recipes</h2>
        <div class="card-body">
        
          <div class="d-grid gap-2 d-md-flex justify-content-md-end">
              <a class="btn btn-primary btn-sm" href="{{ route('recipes.index') }}"><i class="fa fa-arrow-left"></i> Back</a>
          </div>
        
          <form action="{{ route('recipes.store') }}" method="POST" enctype="multipart/form-data">
              @csrf
        
              <div class="mb-3">
                  <label for="nama" class="form-label"><strong>Nama : </strong></label>
                  <input 
                      type="text" 
                      name="nama" 
                      class="form-control @error('nama') is-invalid @enderror" 
                      id="nama" 
                      placeholder="nama"
                      >
                  @error('nama')
                      <div class="form-text text-danger">{{ $message }}</div>
                  @enderror
              </div>
        
              <div class="mb-3">
                  <label for="deskripsi" class="form-label"><strong>Deskripsi : </strong></label>
                  <textarea 
                      class="form-control @error('deskripsi') is-invalid @enderror" 
                      style="height:150px" 
                      name="deskripsi" 
                      id="deskripsi" 
                      placeholder="deskripsi"></textarea>
                  @error('deskripsi')
                      <div class="form-text text-danger">{{ $message }}</div>
                  @enderror
              </div>

              <div class="mb-3">
                <label for="porsi" class="form-label"><strong>Porsi : </strong></label>
                <input 
                    type="number" 
                    name="porsi" 
                    class="form-control @error('porsi') is-invalid @enderror" 
                    id="porsi" 
                    placeholder="porsi">
                @error('porsi')
                    <div class="form-text text-danger">{{ $message }}</div>
                @enderror
            </div>

            <div class="mb-3">
                <label for="bahan" class="form-label"><strong>Bahan : </strong></label>
                <input 
                    type="text" 
                    name="bahan" 
                    class="form-control @error('bahan') is-invalid @enderror" 
                    id="bahan" 
                    placeholder="bahan">
                @error('bahan')
                    <div class="form-text text-danger">{{ $message }}</div>
                @enderror
            </div>

            <div class="mb-3">
                <label for="deskripsi" class="form-label"><strong>Alat : </strong></label>
                <textarea 
                    class="form-control @error('alat') is-invalid @enderror" 
                    style="height:150px" 
                    name="alat" 
                    id="alat" 
                    placeholder="alat"></textarea>
                @error('alat')
                    <div class="form-text text-danger">{{ $message }}</div>
                @enderror
            </div>

            <div class="mb-3">
                <label for="deskripsi" class="form-label"><strong>Tutorial : </strong></label>
                <textarea 
                    class="form-control @error('tutorial') is-invalid @enderror" 
                    style="height:150px" 
                    name="tutorial" 
                    id="tutorial" 
                    placeholder="tutorial"></textarea>
                @error('tutorial')
                    <div class="form-text text-danger">{{ $message }}</div>
                @enderror
            </div>
      
            <div class="mb-3">
                <label for="image" class="form-label"><strong>Gambar : </strong></label>
                <input 
                    type="file" 
                    name="image" 
                    class="form-control @error('image') is-invalid @enderror" 
                    id="image">
                    @error('image')
                      <div class="form-text text-danger">{{ $message }}</div>
                    @enderror
            </div>
      
              <button type="submit" class="btn btn-success"><i class="fa-solid fa-floppy-disk"></i> Submit</button>
          </form>
        
        </div>
      </div>
</div>
@endsection