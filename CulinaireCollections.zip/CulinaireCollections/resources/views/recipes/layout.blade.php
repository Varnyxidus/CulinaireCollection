<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>@yield('title')</title>
    <link rel="stylesheet" href="/bootstrap-5.3.3-dist/css/bootstrap.css">
</head>

{{-- #FFA500 (ORANGE) = 255, 165, 0 --}}

<body>
    <header>
        <nav class="navbar fixed-top bg-body-tertiary" data-bs-theme="dark">
            <div class="container-fluid">
              <a href="/" class="navbar-brand" style="color: rgb(255, 165, 0); font-family:'Courier New', Courier, monospace; font-weight: bold">CulinaireCollections</a>
            <form method="GET" action="/" class="d-flex" role="search">
                @csrf
                <div>
                    <input class="form-control me-2" type="search" name="search" id="search" placeholder="search recipe..." aria-label="Search"/>
                </div> 
                <div>
                    <button type="submit" class="btn btn-outline-warning">Search</button>
                </div>
            </form>
            @auth
            <form action="/logout" method="POST">
            @csrf
                <button href="/" type="submit" class="btn btn-outline-warning">Logout</button>
                </form>
            @else
                <a href="/login" type="submit" class="btn btn-outline-warning">Login</a>
            @endauth
            </div>
          </nav>
    </header>
    <div style="padding-top: 100px">
        @yield('content')
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</body>

</html>