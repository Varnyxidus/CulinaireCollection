<?php

namespace App\Http\Controllers;

use Auth;
use App\Models\Recipe;
use App\Models\User;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\View\View;

class RecipeController extends Controller
{
    public function loginPage(){
        return view('login');
    }

    public function loginForm(Request $req){
        $creds = $req->validate([
            'email' => 'required|email',
            'password'=> 'required|min:8',
        ]);

        if(Auth::attempt($creds)){
            $user = Auth::user();
            return redirect()->route('index')->with('user', $user);
        }

        return back()->withErrors([
            'credentials' => 'Credentials invalid'
        ]);
    }

    public function logout(Request $req){
        Auth::logout();

        return redirect()->route('index');
    }

    public function registerPage(){
        return view('register');
    }

    public function registerForm(Request $req){
        $req->validate([
            'name' => 'required',
            'email' => 'required|email|unique:users',
            'password' => 'required|min:8',
        ]);

        $newuser = $req->all();
        User::create($newuser);
        return redirect()->route('login');
    }

    public function index(Request $req): View
    {       
            $userdata = $req->user();
            if($userdata == null){
                $username = "Guest";
            }else{
                $username = $userdata->name;
            }

            $search = $req->query('search');
            
            if ($search) {
                $recipes = Recipe::where('nama', 'like', "%{$search}%")
                    ->orWhere('id', 'like', "{$search}%")
                    ->orWhere('porsi', 'like', "%{$search}%")
                    ->latest()
                    ->paginate(5);
            } else {
                $recipes = Recipe::latest()->paginate(5);
            }
            
            if($username){
            return view('recipes.index', compact('username','recipes'))
                ->with('i', (request()->input('page', 1) - 1) * 5);
            } else{
            return view('recipes.index', compact('recipes'))
            ->with('i', (request()->input('page', 1) - 1) * 5);
             }
    }


    /**
     * menampilkan form resep 
     */
    public function create(): View
    {
        return view('recipes.create');
    }

    /**
     * Membuat resep baru
     */
    public function store(Request $request)
    {
        $request->validate([
            'nama' => 'required',
            'deskripsi' => 'required',
            'porsi' => 'required',
            'bahan' => 'required',
            'alat' => 'required',
            'tutorial' => 'required',
            'image' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        ]);

        $input = $request->all();

        if ($image = $request->file('image')) {
            $destinationPath = 'image/';
            $profileImage = date('YmdHis') . "." . $image->getClientOriginalExtension();
            $image->move($destinationPath, $profileImage);
            $input['image'] = "$profileImage";
        }

        Recipe::create($input);

        return redirect()->route('recipes.index')
            ->with('success', 'Recipe created successfully.');
    }

    /**
     * menampilkan resep yang spesifik
     */
    public function show(string $id)
    {

    }

    /**
     * untuk mengedit resep
     */
    public function edit(Recipe $recipe): View
    {
        return view('recipes.edit', compact('recipe'));
    }

    /**
     * untuk update resep
     */
    public function update(Request $request, Recipe $recipe): RedirectResponse
    {
        $request->validate([
            'image' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        ]);

        $input = $request->all();

        if ($image = $request->file('image')) {
            $destinationPath = 'image/';
            $profileImage = date('YmdHis') . "." . $image->getClientOriginalExtension();
            $image->move($destinationPath, $profileImage);
            $input['image'] = "$profileImage";
        } else {
            unset($input['image']);
        }

        $recipe->update($input);

        return redirect()->route('recipes.index')
            ->with('success', 'Recipe updated successfully');
    }

    /**
     * untuk menghapus resep
     */
    public function destroy(Recipe $recipe): RedirectResponse
    {
        $recipe->delete();

        return redirect()->route('recipes.index')
            ->with('success', 'Recipe deleted successfully');
    }
}
